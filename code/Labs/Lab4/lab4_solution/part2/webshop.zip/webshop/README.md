# Lab 4 Part 2 - Webshop Components

Spring Boot implementation of:
- Product component: `addProduct`, `getProduct`, `changePrice`
- Shopping component: `addToShoppingCart`, `getShoppingCart`
- MongoDB persistence for products and shopping carts
- REST client flow for the 6 required lab steps

## Tech
- Java 17
- Spring Boot 3
- Spring Web
- Spring Data MongoDB

## Run

1. Start MongoDB:

```bash
cd part2/webshop
docker compose up -d
```

2. Start the application:

```bash
mvn spring-boot:run
```

3. Run the required REST client flow (steps 1-6):

```bash
LAB4_CLIENT_ENABLED=true mvn spring-boot:run
```

The console prints:
- added product
- fetched product
- added to cart
- fetched cart
- changed price
- fetched cart after price change (with updated item price)

## Endpoints

### Product component
- `POST /api/products`
- `GET /api/products/{productNumber}`
- `PATCH /api/products/{productNumber}/price`
- `PUT /api/products/{productNumber}/price`

### Shopping component
- `POST /api/shopping-carts/{customerNumber}/items`
- `GET /api/shopping-carts/{customerNumber}`

## Example payloads

Add product:

```json
{
  "productNumber": "P-1001",
  "name": "Designing Data-Intensive Applications",
  "price": 59.99,
  "description": "Architecture book"
}
```

Add to cart:

```json
{
  "productNumber": "P-1001",
  "quantity": 2
}
```

Update price:

```json
{
  "price": 79.99
}
```
